import 'package:flutter/material.dart';
import 'dashboard.dart';
//import 'package:dashboard/edu.dart';
//import 'package:dashboard/health.dart';
//import 'package:dashboard/roads.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
     /* initialRoute: '/',
      routes: {
        '/': (context) => Dashboard(),
        '/health': (context) => Health(),
        '/edu': (context) => Edu(),
        '/roads': (context) => Roads(),
      },*/
      theme: ThemeData(
        //primarySwatch: Colors.grey,
      ),
      home: Scaffold(

        body:Dashboard(),
      ),
    );
  }
}
